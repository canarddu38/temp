<?php
/**
 * Letter Avatars
 * 
 * Generate random-colored letter avatars. Inspired by DVZ Random Avatars by Tomasz 'Devilshakerz' Mlynski [devilshakerz.com]
 *
 * @package Letter Avatars
 * @author  Shade <shad3-@outlook.com>
 * @license MIT
 * @version 1.0.2
 */

if (!defined('IN_MYBB')) {
	die('Direct initialization of this file is not allowed.<br /><br />Please make sure IN_MYBB is defined.');
}

if (!defined("PLUGINLIBRARY")) {
	define("PLUGINLIBRARY", MYBB_ROOT."inc/plugins/pluginlibrary.php");
}

function letteravatars_info()
{
	global $mybb;

	if (letteravatars_is_installed()) {

	    $description .= ' <a href="index.php?module=config-plugins&amp;letteravatars_assign=1&amp;my_post_key=' . $mybb->post_code . '"><strong>Assign avatars to users with no avatar</strong></a> ';
	    $description .= '– <a href="index.php?module=config-plugins&amp;letteravatars_remove=1&amp;my_post_key=' . $mybb->post_code . '"><strong>Remove Letter Avatars</strong></a> ';
	    $description .= '– <a href="index.php?module=config-plugins&amp;letteravatars_randomize=1&amp;my_post_key=' . $mybb->post_code . '"><strong>Randomize Letter Avatars</strong></a>';

	}

	return [
		'name'          =>  'Letter Avatars',
		'description'   =>  'Generate random-colored letter avatars.' . $description,
		'website'       =>  'https://www.mybboost.com/forum-letter-avatars',
		'author'        =>  'Shade',
		'version'       =>  '1.0.2',
		'compatibility' =>  '18*',
	];
}

function letteravatars_is_installed()
{
    global $cache;

    $installed = $cache->read("shade_plugins");
    if ($installed['Letter Avatars']) {
        return true;
    }

}

function letteravatars_install()
{
	global $cache, $PL, $db;

	if (!file_exists(PLUGINLIBRARY)) {
		flash_message('Letter Avatars could not be installed because PluginLibrary is missing.', 'error');
		admin_redirect('index.php?module=config-plugins');
	}

	$PL or require_once PLUGINLIBRARY;

	$settingsToAdd = [
		'length' => [
			'title' => 'Number of letters',
			'description' => 'How many letters would you like to show in a single avatar?',
			'optionscode' => 'text',
			'value' => '2'
		],
		'hue' => [
			'title' => 'Hue',
			'description' => 'The hue of avatar\'s backgrounds. If no hues are specified, Letter Avatars will generate random colors choosing from aesthetically pleasant hues. You can restrict Letter Avatars\' color generation to fall between a desired hue(s). Separate multiple hues with a coma. Accepted values are: red, orange, yellow, green, blue, purple, pink and monochrome; any integer number between 0 and 360 can be specified as well. You can specify a range of hues by separating them with a "~", for example: 60~240 will restrict hues between 60 (yellow-green) to 240 (blue-purple).',
			'optionscode' => 'textarea',
			'value' => ''
		],
		'luminosity' => [
			'title' => 'Luminosity',
			'description' => 'The luminosity of avatar\'s backgrounds. Darker tones work best on brighter themes and viceversa.',
			'optionscode' => "select \ndark=Dark \nlight=Light \nbright=Bright \nall=All",
			'value' => 'all'
		],
		'round' => [
			'title' => 'Rounded avatar',
			'description' => 'Whether if the generated image should be rounded. If disabled, the image will be shaped as a square.',
			'value' => '0'
		],
		'uppercase' => [
			'title' => 'Uppercase letters',
			'description' => 'Whether if letters should be all uppercase or not. If disabled and an user has lowercase letters, they will not be converted to uppercase.',
			'value' => '1'
		],
		'fontsize' => [
			'title' => 'Font size',
			'description' => 'The font size of initials in the generated image. Values between 0.1 and 1 are accepted, 0.5 by default.',
			'optionscode' => 'text',
			'value' => '0.4'
		]
	];

	$PL->settings('letteravatars', 'Letter Avatars settings', 'Settings for Letter Avatars plugin.', $settingsToAdd);

	$users = $db->simple_select('users', 'uid,username', "avatar=''");

    while ($user = $db->fetch_array($users)) {
		LetterAvatars::addAvatarToUser($user);
	}

	// Add the plugin to cache
    $info = letteravatars_info();
    $shadePlugins = $cache->read('shade_plugins');
    $shadePlugins[$info['name']] = [
        'title' => $info['name'],
        'version' => $info['version']
    ];
    $cache->update('shade_plugins', $shadePlugins);
}

function letteravatars_uninstall()
{
	global $cache, $PL;

	if (!file_exists(PLUGINLIBRARY)) {
		flash_message('Letter Avatars could not be uninstalled because PluginLibrary is missing.', 'error');
		admin_redirect('index.php?module=config-plugins');
	}

	$PL or require_once PLUGINLIBRARY;

	$PL->settings_delete('letteravatars');

	LetterAvatars::deleteAll();

	// Remove the plugin from cache
	$info = letteravatars_info();
    $shadePlugins = $cache->read('shade_plugins');
    unset($shadePlugins[$info['name']]);
    $cache->update('shade_plugins', $shadePlugins);
}

$plugins->add_hook('admin_config_plugins_begin',  ['LetterAvatars', 'admin']);
$plugins->add_hook('usercp_do_avatar_end', ['LetterAvatars', 'updateAvatar']);
$plugins->add_hook('datahandler_user_insert', ['LetterAvatars', 'insertUser']);
$plugins->add_hook('admin_user_users_edit_commit', ['LetterAvatars', 'updateAvatarAdmin']);

include 'LetterAvatars/RandomColor.php';

use \Colors\RandomColor;

class LetterAvatars {

	function admin()
	{
		global $mybb, $db;

		verify_post_check($mybb->get_input('my_post_key'));

		if ($mybb->get_input('letteravatars_assign')) {

			$users = $db->simple_select('users', 'uid,username', "avatar=''");

	        while ($user = $db->fetch_array($users)) {
				self::addAvatarToUser($user);
			}

	        flash_message('Letter Avatars have been assigned to users with no avatar.', 'success');
	        admin_redirect("index.php?module=config-plugins");

		}

		if ($mybb->get_input('letteravatars_randomize')) {

			$users = $db->simple_select(
				'users',
				'uid,username',
				"avatar LIKE '%ui-avatars.com%'"
			);

	        while ($user = $db->fetch_array($users)) {
				self::addAvatarToUser($user);
	        }

	        flash_message('Letter Avatars have been randomized.', 'success');
	        admin_redirect("index.php?module=config-plugins");

		}

		if ($mybb->get_input('letteravatars_remove')) {

			self::deleteAll();

	        flash_message('Letter Avatars have been removed.', 'success');
	        admin_redirect("index.php?module=config-plugins");

		}

	}

	function deleteAll()
	{
		global $db;

		return $db->update_query(
            'users',
            [
                'avatar'           => '',
                'avatartype'       => '',
                'avatardimensions' => '',
            ],
            "avatar LIKE '%ui-avatars.com%'"
        );
	}

	function addAvatarToUser($user = [])
	{
		global $db;

		if (!$user['uid']) {
			return false;
		}

		$avatar = self::generateAvatar($user);

		if ($avatar) {
        	return $db->update_query('users', $avatar, 'uid=' . (int) $user['uid']);
        }
	}

	function updateAvatar()
	{
		global $mybb, $db;

		if (!empty($mybb->get_input('remove'))) {
			self::addAvatarToUser($mybb->user);
		}
	}

	function updateAvatarAdmin()
	{
		global $mybb, $db, $user;

		if ($mybb->input['remove_avatar']) {
			self::addAvatarToUser($user);
		}
	}

	function insertUser(UserDataHandler $UserDataHandler)
    {
        $UserDataHandler->user_insert_data = array_merge(
        	$UserDataHandler->user_insert_data,
        	self::generateAvatar($UserDataHandler->user_insert_data)
        );
    }

	function generateAvatar($user = [])
	{
		global $mybb, $db;

		if (!$user) {
			$user = $mybb->user;
		}

		$options = [
			'luminosity' => trim((string) $mybb->settings['letteravatars_luminosity'])
		];

		// Hue
		if ($mybb->settings['letteravatars_hue']) {

			$rules = array_map(
				'trim',
				explode(',', $mybb->settings['letteravatars_hue'])
			);

			$hues = [];

			foreach ($rules as $hue) {

				if (strpos($hue, '~') !== false) {

					$range = explode('~', $hue);

					$hues = array_merge($hues, range((int) $range[0], (int) $range[1]));

				}
				else {
					$hues[] = $hue;
				}

			}

			if ($hues) {
				$options['hue'] = (array) $hues;
			}

		}

		$size = (int) explode('|', $mybb->settings['useravatardims'])[0];
		$background = str_replace('#', '', RandomColor::one($options));
		$text = self::getContrastColor($background);

		$remoteFile = 'https://ui-avatars.com/api/'
					. '?name=' . urlencode($user['username'])
					. '&size=' . $size
					. '&background=' . $background
					. '&color=' . $text
					. '&length=' . max(0, (int) $mybb->settings['letteravatars_length']);

		if ($mybb->settings['letteravatars_round']) {
			$remoteFile .= '&rounded=true';
		}

		if (!$mybb->settings['letteravatars_uppercase']) {
			$remoteFile .= '&uppercase=false';
		}

		if ((float) $mybb->settings['letteravatars_fontsize'] != 0.5) {
			$remoteFile .= '&font-size=' . min(max(0.1, (float) $mybb->settings['letteravatars_fontsize']), 1);
		}

		$avatar = [
			'avatardimensions' => $size . '|' . $size,
			'avatar' => $db->escape_string($remoteFile),
			'avatartype' => 'remote'
		];

		return $avatar;
	}

	function getContrastColor($hexColor) {

		$hexColor = '#' . $hexColor;

        $R1 = hexdec(substr($hexColor, 1, 2));
        $G1 = hexdec(substr($hexColor, 3, 2));
        $B1 = hexdec(substr($hexColor, 5, 2));

        $blackColor = "#000000";
        $R2BlackColor = hexdec(substr($blackColor, 1, 2));
        $G2BlackColor = hexdec(substr($blackColor, 3, 2));
        $B2BlackColor = hexdec(substr($blackColor, 5, 2));

	    $L1 = 0.2126 * pow($R1 / 255, 2.2) +
	          0.7152 * pow($G1 / 255, 2.2) +
	          0.0722 * pow($B1 / 255, 2.2);

        $L2 = 0.2126 * pow($R2BlackColor / 255, 2.2) +
              0.7152 * pow($G2BlackColor / 255, 2.2) +
              0.0722 * pow($B2BlackColor / 255, 2.2);

        $contrastRatio = 0;
        if ($L1 > $L2) {
            $contrastRatio = (int)(($L1 + 0.05) / ($L2 + 0.05));
        }
        else {
            $contrastRatio = (int)(($L2 + 0.05) / ($L1 + 0.05));
        }

        if ($contrastRatio > 5) {
            return '444';
        }
        else {
            return 'fff';
        }

	}

}